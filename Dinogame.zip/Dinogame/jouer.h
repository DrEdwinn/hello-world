#ifndef JOUER_H_INCLUDED
#define JOUER_H_INCLUDED

void jouer(SDL_Surface *surface);
void sauter(SDL_Rect posDinoy);

#endif // JOUER_H_INCLUDED
